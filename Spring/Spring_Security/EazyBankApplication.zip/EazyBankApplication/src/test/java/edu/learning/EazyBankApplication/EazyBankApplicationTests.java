package edu.learning.EazyBankApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EazyBankApplicationTests {

	@Test
	void contextLoads() {
	}

}
